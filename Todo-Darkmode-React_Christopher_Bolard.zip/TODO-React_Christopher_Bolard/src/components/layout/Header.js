import Navbar from 'react-bootstrap/Navbar';
import Darkmode from '../examples/DarkMode';


function Header() {
  return (
      <Navbar bg="dark" variant="dark">
          <Navbar.Brand href="#home">
            Cours React
          </Navbar.Brand>

          <Darkmode />
      </Navbar>
  );
}

export default Header;