import React from "react";


class DarkMode extends React.Component {
    constructor() {
        super()
        this.state = { switchDark: false };
        this.clickDark = this.clickDark.bind(this);

    }

    clickDark() {

        this.setState(prevState => ({
            switchDark: !prevState.switchDark
        }));

        if (this.state.switchDark === false) {
            document.body.classList.add("dark");
        } else {
            document.body.classList.remove("dark");
        }

    }

    render() {
        return (
            <div >
                <div className="toggle-theme-wrapper">
                    <span>☀️</span>
                    <label className="toggle-theme" htmlFor="checkbox">
                        <input
                            type="checkbox"
                            id="checkbox"
                            onClick={this.clickDark}
                            defaultChecked={this.state.switchDark ? true : false}
                        />
                        <div className="slider round"></div>
                    </label>
                    <span>🌒</span>
                </div>

            </div>
        );
    }
}



export default DarkMode;

