import './App.css';
import Example1 from './components/examples/Example1';
import Example2 from './components/examples/Example2';
import Example3 from './components/examples/Example3';
import Example4 from './components/examples/Example4';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import Todo from './components/TodoList/Todo';
import React from 'react';

function App() {

  const [darkMode, setDarkMode] = React.useState(false);

  React.useEffect(() => {
    const json = localStorage.getItem("site-dark-mode");
    const currentMode = JSON.parse(json);
    if (currentMode) {
      setDarkMode(true);
    } else {
      setDarkMode(false);
    }
  }, []);

  React.useEffect(() => {
    if (darkMode) {
      document.body.classList.add("dark");
    } else {
      document.body.classList.remove("dark");
    }
  }, [darkMode]);

  return (
    <div className="App">
      <Header/>
      <button onClick={() => setDarkMode(!darkMode)}>Toggle Dark Mode</button>
      <div className="mainContent">
        <Todo />
      </div>
      {/* <Footer/> */}
    </div>
  );
}

export default App;
