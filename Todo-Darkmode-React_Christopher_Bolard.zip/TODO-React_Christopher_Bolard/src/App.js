import './App.css';
import Header from './components/layout/Header';
import Todo from './components/TodoList/Todo';
import React from 'react';

function App() {

 

  return (
    <div className="App">
      <Header/>

      <div className="container">
      <h1>To-do List</h1>
      <p>Ajoutez une tâche à la todo-list :</p>
        <Todo />
      </div>
    </div>
  );
}

export default App;